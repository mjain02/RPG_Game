// Project includes
#include "globals.h"
#include "hardware.h"
#include "map.h"
#include "graphics.h"
#include "speech.h"

// Functions in this file
int get_action (GameInputs inputs);
int update_game (int action);
void draw_game (int init);
void init_maps(int map);
static void init_map1();
static void init_map2();
int main ();

/**
 * The main game state. Must include Player locations and previous locations for
 * drawing to work properly. Other items can be added as needed.
 */
struct {
    int x,y;    // Current locations
    int px, py; // Previous locations
    int has_key; //0 for no, 1 for yes
    int speed; //the number of positions the characters moves - default = 1, button 1 = slow if higher, button 3 = increase the speed by 1, max = 3
    // You can add other properties for the player here
} Player;

/**
 * Given the game inputs, determine what kind of update needs to happen.
 * Possbile return values are defined below.
 */
#define NO_ACTION 0
#define ACTION_BUTTON 1
#define MENU_BUTTON 2
#define GO_LEFT 3
#define GO_RIGHT 4
#define GO_UP 5
#define GO_DOWN 6
bool omni = false;

int get_action(GameInputs inputs)
{
    if (inputs.b1 == 1) //button 1 is pressed
        return ACTION_BUTTON;
    if (inputs.b2 == 1) { //omni mode button
        omni = !omni;
        if (omni) { 
        uLCD.locate(0,0);
        uLCD.line(0, 0, 127, 10, BLACK);
        uLCD.printf("Omnipotent mode");
        } else {
        uLCD.locate(0,0);
        uLCD.line(0, 0, 127, 10, BLACK);
        uLCD.printf("Normal mode");
        }
    }
    if (inputs.b3 == 1) //menu
        return MENU_BUTTON;
    if (inputs.b3 == 1) 
        return 0;
    if (inputs.ax > 0.3) 
        return GO_RIGHT;
    if (inputs.ay > 0.3)
        return GO_UP;
    if (inputs.ax < -0.3)
        return GO_LEFT;
    if (inputs.ay < -0.3)
        return GO_DOWN;  
    return NO_ACTION;
}

/**
 * Update the game state based on the user action. For example, if the user
 * requests GO_UP, then this function should determine if that is possible by
 * consulting the map, and update the Player position accordingly.
 * 
 * Return values are defined below. FULL_DRAW indicates that for this frame,
 * draw_game should not optimize drawing and should draw every tile, even if
 * the player has not moved.
 */
#define NO_RESULT 0
#define GAME_OVER 1
#define FULL_DRAW 2
int update_game(int action)
{
    // Save player previous location before updating
    Player.px = Player.x;
    Player.py = Player.y;
    
    // Do different things based on the each action.
    // You can define functions like "go_up()" that get called for each case.
    switch(action)
    {
        MapItem* item;
        case GO_UP:   
            item = get_north(Player.px, Player.py);
            if (item == NULL) {
                Player.y = Player.py - 1; //x stays the same
            } else if (item->type == DOOR) {
                //change map
                
                if(get_map() == 0)
                   { set_active_map(1); //change to the inner map
                    init_maps(1); 
                    Player.x = 10;
                    Player.y = 10;
                    speech("Cast spells to", "fight the monster");
                    speech("Find the key.", "Find exit.");
                    wait_ms(1500);
                    }
                else
                   { set_active_map(0);
                    init_maps(0); 
                    Player.x = 20;
                    Player.y = 20;
                    }
                //draw new map
            } else if (item->type == EXIT && Player.has_key == 1) {
                return GAME_OVER;
            } else if (item->type == FIRE) {
                speech("You have chosen ", "the fire spell");
            } else if (item->type == WATER) {
                speech("You have chosen ", "the water spell");
            } else if (item->walkable || omni) {
                Player.y = Player.py - 1; //x stays the same
            }
            break;
        case GO_LEFT:
            item = get_west(Player.px, Player.py);
            if (item == NULL) {
                Player.x = Player.px - 1; //y stays the same
            } else if (item->type == DOOR) {
                //go through door
                //set active map to 1
                
                if(get_map() == 0)
                  {  set_active_map(1);
                    init_maps(1); 
                    Player.x = 10;
                    Player.y = 10;
                    speech("Cast spells to", "fight the monster");
                    speech("Find the key.", "Find exit.");
                    wait_ms(1500);
                    }
                else
                   { set_active_map(0);
                     init_maps(0); 
                     Player.x = 20;
                    Player.y = 20;
                    }
                //draw new map
            } else if (item->type == EXIT && Player.has_key == 1) {
                return GAME_OVER;
            } else if (item->type == FIRE) {
                speech("You have chosen ", "the fire spell");
            } else if (item->type == WATER) {
                speech("You have chosen ", "the water spell");
            } else if (item->walkable || omni)
                Player.x = Player.px - 1; //y stays the same  
            break;            
        case GO_DOWN:   
            item = get_south(Player.px, Player.py);
            if (item == NULL) {
                Player.y = Player.py + 1; //x stays the same
            } else if (item->type == DOOR) {
                //go through door
                //set active map to 1
                
                if(get_map() == 0)
                  {  set_active_map(1);
                    init_maps(1); 
                    Player.x = 10;
                    Player.y = 10;
                    speech("Cast spells to", "fight the monster");
                    speech("Find the key.", "Find exit.");
                    wait_ms(1500);
                    }
                else
                   { set_active_map(0);
                     init_maps(0); 
                     Player.x = 20;
                    Player.y = 20;
                    }
                //draw new map
            } else if (item->type == EXIT && Player.has_key == 1) {
                return GAME_OVER;
            } else if (item->type == FIRE) {
                speech("You have chosen ", "the fire spell");
            } else if (item->type == WATER) {
                speech("You have chosen ", "the water spell");
            } else if (item->walkable || omni)
                Player.y = Player.py + 1; //x stays the same
            break;
        case GO_RIGHT: 
            item = get_east(Player.px, Player.py);
            if (item == NULL) {
                Player.x = Player.px + 1; //y stays the same
            } else if (item->type == DOOR) {
                //go through door
                //set active map to 1
                
                if(get_map() == 0)
                  {  set_active_map(1);
                    init_maps(1); 
                    Player.x = 10;
                    Player.y = 10;
                    speech("Cast spells to", "fight the monster");
                    speech("Find the key.", "Find exit.");
                    wait_ms(1500);
                }
                else
                   { set_active_map(0);
                     init_maps(0); 
                     Player.x = 20;
                    Player.y = 20;}
                //draw new map
            } else if (item->type == EXIT && Player.has_key == 1) {
                return GAME_OVER;
            } else if (item->type == FIRE) {
                speech("You have chosen ", "the fire spell");
            } else if (item->type == WATER) {
                speech("You have chosen ", "the water spell");
            } else if (item->walkable || omni)
                Player.x = Player.px + 1; //y stays the same
            break;
        case ACTION_BUTTON: 
           
            break;
        case MENU_BUTTON: 
            //clear screen
            //write menu
            //build map based on choices
            break;
        default:        
            break;
    }
    
    return NO_RESULT;
}

/**
 * Entry point for frame drawing. This should be called once per iteration of
 * the game loop. This draws all tiles on the screen, followed by the status 
 * bars. Unless init is nonzero, this function will optimize drawing by only 
 * drawing tiles that have changed from the previous frame.
 */
void draw_game(int init)
{
    // Draw game border first
    if(init) draw_border();
    
    // Iterate over all visible map tiles
    for (int i = -5; i <= 5; i++) // Iterate over columns of tiles
    {
        for (int j = -4; j <= 4; j++) // Iterate over one column of tiles
        {
            // Here, we have a given (i,j)
            
            // Compute the current map (x,y) of this tile
            int x = i + Player.x;
            int y = j + Player.y;
            
            // Compute the previous map (px, py) of this tile
            int px = i + Player.px;
            int py = j + Player.py;
                        
            // Compute u,v coordinates for drawing
            int u = (i+5)*11 + 3;
            int v = (j+4)*11 + 15;
            
            // Figure out what to draw
            DrawFunc draw = NULL;
            if (init && i == 0 && j == 0) // Only draw the player on init
            {
                draw_player(u, v, Player.has_key);
                continue;
            }
            else if (x >= 0 && y >= 0 && x < map_width() && y < map_height()) // Current (i,j) in the map
            {
                MapItem* curr_item = get_here(x, y);
                MapItem* prev_item = get_here(px, py);
                if (init || curr_item != prev_item) // Only draw if they're different
                {
                    if (curr_item) // There's something here! Draw it
                    {
                        draw = curr_item->draw;
                    }
                    else // There used to be something, but now there isn't
                    {
                        draw = draw_nothing;
                    }
                }
            }
            else if (init) // If doing a full draw, but we're out of bounds, draw the walls.
            {
                draw = draw_wall;
            }

            // Actually draw the tile
            if (draw) draw(u, v);
        }
    }

    // Draw status bars    
    draw_upper_status();
    
    draw_lower_status();
    
}

void init_maps(int map)
{
    if (map == 0) {
        init_map1();
    } else if (map == 1) {
        init_map2();
    }
}

/**
 * Initialize the main world map. Add walls around the edges, interior chambers,
 * and plants in the background so you can see motion. Note: using the similar
 * procedure you can init the secondary map(s).
 */
static void init_map1()
{
    Map* map = set_active_map(0); //set the active map to map 1
    // "Random" plants    
    for(int i = map_width() + 5; i < map_area()-1000; i += 39)
    {
        add_plant(i % map_width(), i / map_width());
        //add_rock(i % map_width() + 3, i / map_height() + 3); 
    }
    
    //draw door
    add_door(25, 25);
    add_door(25, 26);
    add_door(26, 26);
    add_door(26, 25);
    
    add_wall(0,              0,              HORIZONTAL, map_width());
    add_wall(0,              map_height()-1, HORIZONTAL, map_width());
    add_wall(0,              0,              VERTICAL,   map_height());
    add_wall(map_width()-1,  0,              VERTICAL,   map_height());
    
    add_exit(30, 30);
    
    pc.printf("Walls done!\r\n");

    print_map(); //debugging
}


static void init_map2() 
{
    Map* map = set_active_map(1); //set the active map to map 2
    
    for(int i = map_height(); i < map_area(); i +=41)
    {
        add_rock(i % map_width()+3, i % map_height()+10);
    }
    
    add_door(25, 25);
    add_door(25, 26);
    add_door(26, 25);
    add_door(26, 26);
    
    add_waterspell(15, 15);
    add_firespell(18, 15);
    
    
    add_key(35, 35);
    add_monster(17, 17);
}
/**
 * Program entry point! This is where it all begins.
 * This function orchestrates all the parts of the game. Most of your
 * implementation should be elsewhere - this holds the game loop, and should
 * read like a road map for the rest of the code.
 */
int main()
{
    // First things first: initialize hardware
    ASSERT_P(hardware_init() == ERROR_NONE, "Hardware init failed!");
    // Initialize the maps
    maps_init();
    init_maps(0); //draw first map
    // Initialize game state
    set_active_map(0);
    Player.x = Player.y = 5;
    
    // Initial drawing
    draw_game(true);
    while(1)
    {
        // Timer to measure game update speed
        Timer t; t.start();
        
        // Actually do the game update:
        // 1. Read inputs  
        GameInputs in = read_inputs();      
        // 2. Determine action (get_action) 
        int action = get_action(in);       
        // 3. Update game (update_game)
        int state = update_game(action);
        // 3b. Check for game over
        if (state == GAME_OVER) {
            break;
        }
        MapItem* ifKey = get_here(Player.x, Player.y);
        if(ifKey->type == KEY){
            Player.has_key = 1;
            speech("Found the key","");
            draw_game(FULL_DRAW);
        }
        // 4. Draw frame (draw_game)
        draw_game(true);
        uLCD.locate(0,15); 
        uLCD.printf("Position: (%d, %d)", Player.x, Player.y);
        
        // 5. Frame delay
        t.stop();
        int dt = t.read_ms();
        if (dt < 100) wait_ms(100 - dt);
    }
    
    uLCD.cls(); //clear screen
    uLCD.locate(5, 8); //center of the screen
    uLCD.printf("GAME OVER");
    
}
